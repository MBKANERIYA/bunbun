import{y as i}from"./index-D98WjfBM.js";const p=()=>i.jsx("div",{children:"ShippingPolicy"});export{p as default};
