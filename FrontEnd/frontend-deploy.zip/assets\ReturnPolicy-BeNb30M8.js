import{y as r}from"./index-D98WjfBM.js";const e=()=>r.jsx("div",{children:"ReturnPolicy"});export{e as default};
